(() => {
    "use strict";

    const namespace = "http://www.w3.org/2000/svg";
    const languageKey = "expogreen-language";
    const animationKey = "expogreen-tree-arrivals";

    const translations = {
        ar: {
            language_selector: "اختيار اللغة",
            experience_eyebrow: "خُطــــوة تصنع أثرًا",
            tree_tag: "أثرٌ يبقــــى",
            tree_title: "شجــــرة الأثر",
            tree_description:
                "كل ورقة تحمل اسم زائر أكمل عملية الفــــرز.",
            tree_accessible_title: "شجرة تحمل أسماء المشاركين",
            tree_accessible_description:
                "تُضاف ورقة باسم الزائر بعد إكمال عملية فرز مؤهلة للنقاط.",
            tree_root: "أثرنــــا يكبر معًا",
            tree_count_label: "مشارك في شجــــرة الأثر",
            tree_empty: "كن أول من يضيف ورقــــة.",
        },
        en: {
            language_selector: "Choose language",
            experience_eyebrow: "A small step. A lasting impact.",
            tree_tag: "Growing together",
            tree_title: "The Impact Tree",
            tree_description:
                "Every leaf represents a visitor who completed a sorting session.",
            tree_accessible_title: "A tree displaying participant names",
            tree_accessible_description:
                "A leaf bearing the visitor’s name is added after a completed sorting session eligible for points.",
            tree_root: "Our impact grows together",
            tree_count_label: "participants in the Impact Tree",
            tree_empty: "Be the first to add a leaf.",
        },
    };

    const positions = [
        [300, 115], [218, 146], [382, 146],
        [146, 193], [260, 204], [340, 204], [455, 193],
        [100, 253], [192, 262], [300, 273],
        [405, 262], [505, 253],
        [121, 326], [233, 330], [361, 330], [473, 326],
        [160, 396], [269, 397], [382, 397], [478, 398],
        [220, 461], [332, 464], [113, 452], [431, 463],
    ];

    const colors = [
        "#426B52",
        "#376E65",
        "#665176",
        "#75613B",
    ];

    const angles = [
        -12, -24, 22, -20, -8, 10, 22,
        -15, -18, 0, 18, 15,
        -12, -8, 8, 12,
        -16, -6, 12, 18,
        -12, 8, -18, 15,
    ];

    function readJson(id, fallback) {
        const node = document.getElementById(id);

        if (!node) {
            return fallback;
        }

        try {
            return JSON.parse(node.textContent);
        } catch {
            return fallback;
        }
    }

    function readStorage(storage, key, fallback) {
        try {
            return storage.getItem(key) || fallback;
        } catch {
            return fallback;
        }
    }

    function saveStorage(storage, key, value) {
        try {
            storage.setItem(key, value);
        } catch {
            // تستمر الواجهة إذا كان التخزين غير متاح.
        }
    }

    function element(tag, attributes = {}) {
        const node = document.createElementNS(namespace, tag);

        for (const [key, value] of Object.entries(attributes)) {
            node.setAttribute(key, String(value));
        }

        return node;
    }

    let language = "ar";

    try {
        language = readStorage(
            window.localStorage,
            languageKey,
            "ar"
        );
    } catch {
        language = "ar";
    }

    if (!Object.hasOwn(translations, language)) {
        language = "ar";
    }

    const rawLeaves = readJson("tree-data", []);
    const leaves = Array.isArray(rawLeaves) ? rawLeaves : [];
    const newVisitor = readJson("tree-new-visitor", null);
    const container = document.getElementById("tree-leaves");

    let animatedVisitors = [];

    try {
        const saved = readStorage(
            window.sessionStorage,
            animationKey,
            "[]"
        );
        const parsed = JSON.parse(saved);
        animatedVisitors = Array.isArray(parsed) ? parsed : [];
    } catch {
        animatedVisitors = [];
    }

    const newVisitorId =
        newVisitor === null || newVisitor === undefined
            ? null
            : String(newVisitor);

    const shouldAnimate =
        newVisitorId !== null &&
        !animatedVisitors.includes(newVisitorId);

    const leafDescriptions = [];

    function contributionText(person) {
        const name = String(person.name || "").trim();
        const count = Math.max(
            0,
            Number(person.contributions) || 0
        );

        if (language === "en") {
            return `${name} — ${count} ${
                count === 1 ? "contribution" : "contributions"
            }`;
        }

        return `${name} — عدد المشاركات: ${count}`;
    }

    function shortenName(name) {
        let characters;

        if (typeof Intl.Segmenter === "function") {
            const segmenter = new Intl.Segmenter(undefined, {
                granularity: "grapheme",
            });

            characters = Array.from(
                segmenter.segment(name),
                (part) => part.segment
            );
        } else {
            characters = Array.from(name);
        }

        return characters.length > 11
            ? `${characters.slice(0, 10).join("")}…`
            : name;
    }

    function updateLeafDescriptions() {
        for (const item of leafDescriptions) {
            const description = contributionText(item.person);
            item.title.textContent = description;
            item.leaf.setAttribute("aria-label", description);
        }
    }

    function renderTree() {
        if (!container) {
            return;
        }

        container.replaceChildren();
        leafDescriptions.length = 0;

        let addedNewLeaf = false;

        leaves.slice(0, positions.length).forEach((person, index) => {
            if (!person || typeof person !== "object") {
                return;
            }

            const name = String(person.name || "").trim();

            if (!name) {
                return;
            }

            const [x, y] = positions[index];
            const angle = angles[index];
            const color = colors[index % colors.length];

            // المجموعة الخارجية تحفظ موضع الورقة على الشجرة.
            const holder = element("g", {
                transform: `translate(${x} ${y})`,
            });

            const isNew =
                shouldAnimate &&
                person.id !== null &&
                person.id !== undefined &&
                String(person.id) === newVisitorId;

            // الحركة على مجموعة داخلية حتى لا تلغي موضع الورقة.
            const leaf = element("g", {
                class: isNew
                    ? "participant-leaf new-leaf"
                    : "participant-leaf",
                role: "img",
            });

            if (isNew) {
                addedNewLeaf = true;
            }

            const title = element("title");
            leaf.appendChild(title);

            const artwork = element("g", {
                transform: `rotate(${angle})`,
                "aria-hidden": "true",
            });

            // عنق الورقة.
            artwork.appendChild(element("path", {
                d: "M-49 5 Q-44 2 -39 0",
                fill: "none",
                stroke: "#7A8069",
                "stroke-width": "2",
                "stroke-linecap": "round",
            }));

            // سطح الورقة.
            artwork.appendChild(element("path", {
                d: [
                    "M-44 0",
                    "C-27-25 8-25 44 0",
                    "C22 23-15 27-44 0Z",
                ].join(" "),
                fill: color,
                stroke: "#F5F6EF",
                "stroke-width": "1.5",
            }));

            // عروق خفيفة.
            artwork.appendChild(element("path", {
                d: [
                    "M-34 0 Q0-3 33 0",
                    "M-17-1 L-7-13",
                    "M3-1 L14-13",
                    "M-7 0 L4 13",
                    "M15 0 L25 9",
                ].join(" "),
                fill: "none",
                stroke: "#FFFFFF",
                "stroke-opacity": ".14",
                "stroke-width": "1",
                "stroke-linecap": "round",
            }));

            leaf.appendChild(artwork);

            // يبقى الاسم أفقيًا لتسهيل القراءة.
            const text = element("text", {
                x: "0",
                y: "1",
                "text-anchor": "middle",
                "dominant-baseline": "middle",
                class: "leaf-name",
                direction: /[\u0600-\u06FF]/.test(name)
                    ? "rtl"
                    : "ltr",
            });

            text.style.unicodeBidi = "plaintext";
            text.textContent = shortenName(name);

            leaf.appendChild(text);
            holder.appendChild(leaf);
            container.appendChild(holder);

            leafDescriptions.push({ person, title, leaf });
        });

        updateLeafDescriptions();

        if (addedNewLeaf) {
            animatedVisitors.push(newVisitorId);
            animatedVisitors = animatedVisitors.slice(-100);

            try {
                saveStorage(
                    window.sessionStorage,
                    animationKey,
                    JSON.stringify(animatedVisitors)
                );
            } catch {
                // لا يؤثر فشل التخزين على رسم الشجرة.
            }
        }
    }

    function applyLanguage(nextLanguage) {
        if (!Object.hasOwn(translations, nextLanguage)) {
            return;
        }

        language = nextLanguage;

        document.documentElement.lang = language;
        document.documentElement.dir =
            language === "ar" ? "rtl" : "ltr";

        document.querySelectorAll("[data-i18n]").forEach((node) => {
            const key = node.dataset.i18n;
            const value = translations[language][key];

            if (value !== undefined) {
                node.textContent = value;
            }
        });

        document.querySelectorAll("[data-i18n-aria]").forEach((node) => {
            const key = node.dataset.i18nAria;
            const value = translations[language][key];

            if (value !== undefined) {
                node.setAttribute("aria-label", value);
            }
        });

        document.querySelectorAll("[data-language]").forEach((button) => {
            const active = button.dataset.language === language;

            button.classList.toggle("is-active", active);
            button.setAttribute("aria-pressed", String(active));
        });

        updateLeafDescriptions();

        try {
            saveStorage(
                window.localStorage,
                languageKey,
                language
            );
        } catch {
            // يعمل تبديل اللغة حتى دون حفظ الاختيار.
        }

        document.dispatchEvent(new CustomEvent(
            "expogreen:languagechange",
            { detail: { language } }
        ));
    }

    document.querySelectorAll("[data-language]").forEach((button) => {
        button.addEventListener("click", () => {
            applyLanguage(button.dataset.language);
        });
    });

    renderTree();
    applyLanguage(language);
})();